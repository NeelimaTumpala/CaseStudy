//package com.capgemini.Exception;
//
//public class FruitsAPIException extends Exception{
//	public FruitsAPIException() {
//		super();
//	}
//	public FruitsAPIException(String  message) {
//		super(message);
//	}
//}
