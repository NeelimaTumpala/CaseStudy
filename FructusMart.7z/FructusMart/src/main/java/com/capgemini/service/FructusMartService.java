package com.capgemini.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.query.Param;

//import com.capgemini.Exception.FruitsAPIException;
import com.capgemini.entity.FructusMart;


public interface FructusMartService {
	
	public void add(FructusMart fruct)throws Exception;
	
	public List<FructusMart> getAll()throws Exception;
	
	public void update(FructusMart fruct,Integer id)throws Exception;
	
	public void delete(Integer id)throws Exception;
	
	public FructusMart findByName(String name)throws Exception;
	
	public String findNameByFructusId(Integer fructusId)throws Exception;
	
	public List<FructusMart> getByStatus(String status)throws Exception;
	
	public Integer findPricePerKgByName(String name)throws Exception;
	
	//public List<FructusMart> findByNameOrderByPricePerKg(Integer price) throws Exception;
	
	

}
