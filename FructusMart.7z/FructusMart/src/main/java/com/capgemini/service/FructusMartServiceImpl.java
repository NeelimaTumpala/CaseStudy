package com.capgemini.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

//import com.capgemini.Exception.FruitsAPIException;

import com.capgemini.entity.FructusMart;

import com.capgemini.repository.FructusMartRepository;

@Service
@Transactional
public class FructusMartServiceImpl implements FructusMartService{
	
	@Autowired
	public FructusMartRepository repo;

	@Override
	public void add(FructusMart fruct) throws Exception {
		Optional<FructusMart>op=repo.findById(fruct.getFructusId());
		if(op.isPresent())
			throw new Exception("Fruit is already present!!!");
		
		repo.save(fruct);
		
	}

	@Override
	public List<FructusMart> getAll() throws Exception {
		Iterable<FructusMart> fructus=repo.findAll();
		List<FructusMart> ma=new ArrayList<>();
		fructus.forEach(c->{
			FructusMart c1=new FructusMart();
			c1.setFructusId(c.getFructusId());
			c1.setName(c.getName());
			c1.setPricePerKg(c.getPricePerKg());
			c1.setQuantity(c.getQuantity());
			c1.setStatus(c.getStatus());
			
			ma.add(c1);
		});
		
	
		return ma;
	}

	@Override
	public void update(FructusMart fruct, Integer id) throws Exception {
		Optional<FructusMart>op=repo.findById(id);
		FructusMart m=op.orElseThrow(()->new Exception("Fruit is not present in the shop!!!"));
		m.setName(fruct.getName());
		m.setPricePerKg(fruct.getPricePerKg());
		m.setQuantity(fruct.getQuantity());
		m.setStatus(fruct.getStatus());
		
		
		
	}

	@Override
	public void delete(Integer id) throws Exception {
		Optional<FructusMart>op=repo.findById(id);
		FructusMart m=op.orElseThrow(()->new Exception("Fruit is not present in the shop!!!"));
		
		repo.delete(m);
		
	}

	@Override
	public FructusMart findByName(String name) throws Exception {
		Optional<FructusMart> optional= repo.findByName(name);
		FructusMart e=optional.orElseThrow(()->new Exception("empNotFound"));
		return e;
		
	}

	@Override
	public String  findNameByFructusId(Integer fructusId) throws Exception {
		return repo.findNameByFructusId(fructusId);
		
		
	}

	@Override
	public List<FructusMart> getByStatus(String status) throws Exception {
		Iterable<Integer> id=repo.getByStatus(status);
		
		Iterable<FructusMart> fruct=repo.findAllById(id);
		List<FructusMart> ma=new ArrayList<>();
		fruct.forEach(m->{
			FructusMart m1=new FructusMart();
			m1.setFructusId(m.getFructusId());
			m1.setName(m.getName());
			m1.setPricePerKg(m.getPricePerKg());
			m1.setQuantity(m.getQuantity());
			m1.setStatus(m.getStatus());
			ma.add(m1);
		});
		return ma;
	}

	@Override
	public Integer findPricePerKgByName(String name) throws Exception{
		
		return repo.findPricePerKgByName(name);
	}

//	@Override
//	public List<FructusMart> findByNameOrderByPricePerKg(Integer price) throws Exception {
//		Iterable<FructusMart> fructus=repo.findByNameOrderByPricePerKg(price);
//		List<FructusMart> list=new ArrayList<>();
//		
//		fructus.forEach(m->{
//			FructusMart m1=new FructusMart();
//			
//			m1.setName(m.getName());
//			
//			list.add(m1);
//		});
//		
//		return list;
//	}

	

}
