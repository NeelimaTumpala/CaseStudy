//package com.capgemini.api;
//
//import java.util.List;
//
//import javax.validation.Valid;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Repository;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
////import com.capgemini.Exception.FruitsAPIException;
//import com.capgemini.entity.FructusMart;
//import com.capgemini.service.FructusMartServiceImpl;
//
//@RestController
//@RequestMapping("/capgemini")
//public class FructusMartApi {
//	
//	@Autowired
//	private FructusMartServiceImpl serv;
//	
//	@RequestMapping("/loginadmin")
//	public ResponseEntity<String> welcome1(){
//		return new ResponseEntity<String> ("Admin login successful!!!",HttpStatus.CREATED);
//	}
//	@GetMapping("/logincust")
//	public ResponseEntity<String> welcome2(){
//		return new ResponseEntity<String> ("Customer login successful!!!",HttpStatus.CREATED);
//	}
//
//	@GetMapping("/logout")
//	public ResponseEntity<String> welcome3(){
//		return new ResponseEntity<String> ("Logout successful...Thank you!!",HttpStatus.CREATED);
//	}
//	
//	@PostMapping("/saveFruit")
//	public ResponseEntity<String> save(@RequestBody FructusMart fruct) throws Exception
//	{
//		
//		serv.add(fruct);
//		return new ResponseEntity<String> ("Fruit added Successfully!!!",HttpStatus.CREATED);
//	}
//	
//	@GetMapping("/getAllFruits")
//	public ResponseEntity<List<FructusMart>> getAll() throws Exception{
//		List< FructusMart> ma=serv.getAll();
//		return new ResponseEntity<List<FructusMart>> (ma,HttpStatus.CREATED);
//	}
//	
//	@PutMapping("/update/{id}")
//	public ResponseEntity<String> update(@PathVariable Integer id,@RequestBody FructusMart fruct) throws Exception{
//		
//		serv.update(fruct, id);
//		return new ResponseEntity<String> ("Record of fruits updated succesfully!!!",HttpStatus.CREATED);
//	}
//	
//	@DeleteMapping("/delete/{id}")
//	public ResponseEntity<String> delete(@PathVariable Integer id) throws Exception{
//		serv.delete(id);
//		return new ResponseEntity<String> ("Record of fruits deleted succesfully!!!",HttpStatus.CREATED);
//	}
//	
//	@GetMapping("/getByName/{name}")
//	public ResponseEntity<FructusMart> getByName( @PathVariable String name) throws Exception {
//		FructusMart ma = serv.findByName(name);
//		return new ResponseEntity<FructusMart> (ma,HttpStatus.OK);
//		}
//	
//	@GetMapping("/getNameById/{id}")
//	public ResponseEntity<String> getNameById(@PathVariable Integer id) throws Exception{
//		String ma =serv.findNameByFructusId(id);
//		return new ResponseEntity<String> (ma,HttpStatus.OK);
//	}
//	
//	@GetMapping("/getByStatus/{status}")
//	public ResponseEntity<List<FructusMart>> getCustomerByStatus(@PathVariable String status) throws Exception {
//		List<FructusMart> li=serv.getByStatus(status);
//		return new ResponseEntity<List<FructusMart>> (li,HttpStatus.OK);
//	}
//	
//	@GetMapping("/getPriceByName/{name}")
//	public ResponseEntity<Integer> getPriceByName(@PathVariable String name) throws Exception{
//		Integer ma=serv.findPricePerKgByName(name);
//		return new ResponseEntity<Integer> (ma,HttpStatus.OK);
//	}
//	
////	@GetMapping("/getByNameOrderByPricePerKg/{price}")
////	public ResponseEntity<List<FructusMart>> getByNameOrderByPricePerKg(Integer price) throws Exception{
////		List<FructusMart> li=serv.findByNameOrderByPricePerKg(price);
////		return new ResponseEntity<List<FructusMart>> (li,HttpStatus.OK);
////	}
//
//
//}
//	
//	
//
//
