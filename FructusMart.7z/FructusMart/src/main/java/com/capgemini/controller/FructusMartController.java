package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.capgemini.entity.FructusMart;
import com.capgemini.service.FructusMartServiceImpl;

@Controller
@RequestMapping("/capgemini")
public class FructusMartController {
	
	@Autowired
	public FructusMartServiceImpl serv;
	
	
	@RequestMapping(value="/getAllFruits")
	public ModelAndView getAllFruits() {

		List<FructusMart> fruit;
		try {
				ModelAndView mav=new ModelAndView("fruits");
				fruit = serv.getAll();
				System.out.print(fruit);
				mav.addObject("fruits", fruit);
				return mav;
		} catch (Exception e) {
			ModelAndView mav=new ModelAndView("error");
			mav.addObject("message", e.getMessage());
			return mav;
		}
		
	}
	
	@RequestMapping(value="/getFruitsByStatus") 
	public ModelAndView getFruitsByStatusButton() 
	{
		ModelAndView mav = new ModelAndView("status");
		return mav; 
	 }
	
	@GetMapping(value="/status")
	public ModelAndView getStatus(@RequestParam String status) throws Exception{
		System.out.println(status);
		ModelAndView mav = new ModelAndView("fruits");
		
		List<FructusMart> fruits = serv.getByStatus(status);
		System.out.println(fruits);
		mav.addObject("fruits", fruits);
		return mav;
		
		
	}

}
