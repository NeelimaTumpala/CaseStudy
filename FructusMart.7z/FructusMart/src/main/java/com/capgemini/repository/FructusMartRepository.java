package com.capgemini.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.entity.FructusMart;

@Repository
public interface FructusMartRepository extends CrudRepository<FructusMart, Integer>{
	Optional<FructusMart> findByName(String name);
	
	@Query("select e.name from FructusMart e where e.fructusId= :fructusId")
	String findNameByFructusId(@Param("fructusId") Integer fructusId);
	
	@Query("select e.fructusId from FructusMart e where e.status= :status")
	Iterable<Integer> getByStatus(@Param("status")String status);
	
	@Query("select e.pricePerKg from FructusMart e where e.name= :name")
	Integer findPricePerKgByName(@Param("name") String name );
	
//	@Query("select e.name from FructusMart e where e.pricePerKg<= :pricePerKg")
//	List<FructusMart> findByNameOrderByPricePerKg(Integer price);

}
