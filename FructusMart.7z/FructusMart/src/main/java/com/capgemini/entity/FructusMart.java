package com.capgemini.entity;

import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity

public class FructusMart {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer fructusId;
	
	private String name;
	
	private Integer pricePerKg;
	
	private Integer quantity;
	
	private String status;
	
	
	
	

	public Integer getFructusId() {
		return fructusId;
	}

	public void setFructusId(Integer fructusId) {
		this.fructusId = fructusId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getPricePerKg() {
		return pricePerKg;
	}

	public void setPricePerKg(Integer pricePerKg) {
		this.pricePerKg = pricePerKg;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "FructusMart [fructusId=" + fructusId + ", name=" + name + ", pricePerKg=" + pricePerKg + ", quantity="
				+ quantity + ", status=" + status + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(fructusId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FructusMart other = (FructusMart) obj;
		return Objects.equals(fructusId, other.fructusId);
	}
	
	
	
	

}
